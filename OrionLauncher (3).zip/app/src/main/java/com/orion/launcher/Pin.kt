package com.orion.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Build
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

/** Receives "Add to home screen" requests for shortcuts (Chrome, messengers...) and hands them to the launcher. */
class PinActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val la = getSystemService(LauncherApps::class.java)
                val req = la.getPinItemRequest(intent)
                if (req != null && req.requestType == LauncherApps.PinItemRequest.REQUEST_TYPE_SHORTCUT && req.isValid) {
                    val si = req.shortcutInfo
                    if (si != null && req.accept()) {
                        val sp = getSharedPreferences("orion", 0)
                        val a = JSONArray(sp.getString("pinq", "[]"))
                        a.put(JSONObject().put("pkg", si.getPackage()).put("id", si.id))
                        sp.edit().putString("pinq", a.toString()).apply()
                        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        } catch (e: Exception) {}
        finish()
    }
}
