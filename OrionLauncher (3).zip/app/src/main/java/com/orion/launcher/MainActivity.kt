package com.orion.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.Dialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    lateinit var sp: SharedPreferences
    lateinit var lay: Layout
    lateinit var root: FrameLayout
    lateinit var pager: Pg
    lateinit var pages: LinearLayout
    lateinit var dots: LinearLayout
    lateinit var dock: LinearLayout
    lateinit var strip: LinearLayout
    lateinit var drawer: LinearLayout
    lateinit var dsearch: EditText
    lateinit var drv: RecyclerView
    lateinit var wm: AppWidgetManager
    lateinit var host: AppWidgetHost
    lateinit var rcv: BroadcastReceiver
    lateinit var flingDet: GestureDetector
    lateinit var scaleDet: ScaleGestureDetector
    val handler = Handler(Looper.getMainLooper())
    val dad = DAd()
    val wcache = HashMap<Int, AppWidgetHostView>()
    var pendingId = -1
    var apps = listOf<App>()
    var results = listOf<Any>()
    var q = ""
    var cres = listOf<Hit>()
    var cq = ""
    var wres = listOf<Hit>()
    var wq = ""
    var dragItem: Item? = null
    var dragApp: App? = null
    var dragDock: String? = null
    var dragging = false
    var spare = false
    var drawerOpen = false
    var torchOn = false
    var twoOn = false
    var twoN = 2
    var alarmTv: TextView? = null
    val scCache = HashMap<String, ShortcutInfo>()
    var twoY = 0f
    var cum = 1f
    var lastW = 0
    var lastH = 0
    var edgeDir = 0
    val edgeRun = Runnable { edgeFlip() }
    val searchRun = Runnable { startAsyncSearch() }


    var loadGen = 0
    var hcache: JSONObject? = null
    var fcache: JSONObject? = null
    val coll: java.text.Collator = java.text.Collator.getInstance()
    lateinit var sbar: LinearLayout
    lateinit var sbText: TextView
    lateinit var sbIcon: ImageView
    val applyRun = Runnable { applyAll() }
    val badgeRun = Runnable { renderHome(false); rebuildDock() }
    fun applyLater() { handler.removeCallbacks(applyRun); handler.postDelayed(applyRun, 160) }

    // ---------- Material You palette (dynamic colors on Android 12+) ----------
    fun nightMode() = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
    fun dyn(id: Int, fb: Int): Int = if (Build.VERSION.SDK_INT >= 31) try { resources.getColor(id, theme) } catch (e: Exception) { fb } else fb
    fun cAccent(): Int = if (nightMode()) dyn(android.R.color.system_accent1_200, 0xFFD0BCFF.toInt()) else dyn(android.R.color.system_accent1_600, 0xFF6750A4.toInt())
    fun cOnAccent(): Int = if (nightMode()) dyn(android.R.color.system_accent1_800, 0xFF381E72.toInt()) else dyn(android.R.color.system_accent1_0, 0xFFFFFFFF.toInt())
    fun cContainer(): Int = if (nightMode()) dyn(android.R.color.system_neutral1_800, 0xFF2B2930.toInt()) else dyn(android.R.color.system_neutral1_50, 0xFFF3EDF7.toInt())
    fun cSurface(): Int = if (nightMode()) dyn(android.R.color.system_neutral1_900, 0xFF1C1B1F.toInt()) else dyn(android.R.color.system_neutral1_10, 0xFFFEF7FF.toInt())
    fun cText(): Int = if (nightMode()) dyn(android.R.color.system_neutral1_100, 0xFFE6E0E9.toInt()) else dyn(android.R.color.system_neutral1_900, 0xFF1D1B20.toInt())
    fun cText2(): Int = if (nightMode()) dyn(android.R.color.system_neutral2_200, 0xFFCAC4D0.toInt()) else dyn(android.R.color.system_neutral2_700, 0xFF49454F.toInt())
    fun cTonal(): Int = if (nightMode()) dyn(android.R.color.system_accent1_700, 0xFF4A4458.toInt()) else dyn(android.R.color.system_accent1_100, 0xFFE8DEF8.toInt())
    fun cOnTonal(): Int = if (nightMode()) dyn(android.R.color.system_accent1_100, 0xFFE8DEF8.toInt()) else dyn(android.R.color.system_accent1_900, 0xFF1D192B.toInt())
    fun withAlpha(c: Int, a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
    fun rr(c: Int, r: Float): GradientDrawable = GradientDrawable().apply { setColor(c); cornerRadius = r }
    fun ripple(): Drawable? { val t = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, t, true); return getDrawable(t.resourceId) }
    fun rowsN(): Int { val r = gi("hrows", 0); return if (r > 0) r else maxOf(3, pageH() / dp(iconDp() + 44f)) }

    fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    fun gi(k: String, d: Int) = sp.getInt(k, d)
    fun gb(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun gs(k: String, d: String): String = sp.getString(k, d) ?: d
    fun iconDp() = sp.getFloat("iconf", 56f)
    fun hidden(): MutableSet<String> = sp.getStringSet("hid", emptySet())!!.toMutableSet()
    fun dockList() = gs("dock", "").split(",").filter { it.isNotBlank() }
    fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    fun curPage(): Int = if (pager.width > 0) (pager.scrollX + pager.width / 2) / pager.width else 0
    fun goPage(i: Int) { if (pager.width > 0) pager.smoothScrollTo(i.coerceIn(0, maxOf(0, pages.childCount - 1)) * pager.width, 0) }
    fun pageW(): Int = if (pager.width > 0) pager.width else resources.displayMetrics.widthPixels
    fun pageH(): Int = if (pager.height > 0) pager.height else (resources.displayMetrics.heightPixels * .7f).toInt()

    // ---------- liquid glass ----------
    fun glass(r: Float, extra: Int = 0): Drawable = rr(withAlpha(cContainer(), 0xDD + extra), r)
    fun applyWin() { if (Build.VERSION.SDK_INT >= 31) try { window.setBackgroundBlurRadius(dp(gi("wblur", 0).toFloat())) } catch (e: Exception) {} }
    fun applyImmersive() {
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (gb("hidebar", false)) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN
        window.decorView.systemUiVisibility = f
    }
    fun gd(v: View, dim: Float = 0.45f): Dialog {
        val dg = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        val card = FrameLayout(this).apply { background = rr(cContainer(), dp(28f).toFloat()); addView(v) }
        dg.setContentView(card)
        dg.window?.let { w ->
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); w.setDimAmount(dim)
            w.setLayout(minOf((resources.displayMetrics.widthPixels * .92).toInt(), dp(420f)), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dg.show()
        card.alpha = 0f; card.scaleX = .92f; card.scaleY = .92f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        return dg
    }
    fun tv(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(cText()); if (bold) typeface = Typeface.DEFAULT_BOLD }
    // ---------- gestures / actions ----------
    fun glob(c: Int) { if (Lock.inst?.performGlobalAction(c) == null) toast("Сначала включите службу специальных возможностей Orion") }
    fun bar(m: String) {
        try { Class.forName("android.app.StatusBarManager").getMethod(m).invoke(getSystemService("statusbar")) }
        catch (e: Exception) { val g = if (m == "expandSettingsPanel") 5 else 4; if (Lock.inst?.performGlobalAction(g) == null) toast("Не удалось открыть шторку") }
    }
    fun inView(v: View, x: Float, y: Float): Boolean { val l = IntArray(2); v.getLocationOnScreen(l); return x >= l[0] && x <= l[0] + v.width && y >= l[1] && y <= l[1] + v.height }
    fun torch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { toast("Нет фонарика"); return }
            torchOn = !torchOn; cm.setTorchMode(id, torchOn)
        } catch (e: Exception) { toast("Фонарик недоступен") }
    }
    fun act(i: Int, key: String = "") {
        when (i) {
            1 -> bar("expandNotificationsPanel"); 2 -> bar("expandSettingsPanel"); 3 -> glob(8); 4 -> settings()
            5 -> openDrawer(true); 6 -> glob(3); 7 -> glob(6); 8 -> glob(9)
            9 -> openDrawer(false); 10 -> homeMenu(); 11 -> torch(); 12 -> goPage(0); 13 -> addWidget()
            14 -> { val p = gs(key + "_app", ""); val a = apps.find { it.pkg == p }; if (a != null) launch(a, null) else toast("Выберите приложение в настройках") }
            15 -> try { startActivity(Intent("android.intent.action.VOICE_COMMAND").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Голосовой поиск недоступен") }
            16 -> try { startActivity(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Камера недоступна") }
            17 -> goPage(curPage() + 1); 18 -> goPage(curPage() - 1)
            19 -> try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            20 -> { val a = recentApps().firstOrNull(); if (a != null) launch(a, null) else toast("Пока нет недавних приложений") }
            21 -> try { startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            else -> {}
        }
    }
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (!dragging) {
            flingDet.onTouchEvent(e); scaleDet.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (e.pointerCount == 2) { twoOn = true; twoN = 2; twoY = (e.getY(0) + e.getY(1)) / 2 }
                    else if (e.pointerCount == 3) { twoOn = true; twoN = 3; twoY = (e.getY(0) + e.getY(1) + e.getY(2)) / 3 }
                }
                MotionEvent.ACTION_POINTER_UP -> if (twoOn && e.pointerCount == twoN && !drawerOpen) {
                    twoOn = false
                    var sy = 0f; for (i in 0 until e.pointerCount) sy += e.getY(i)
                    val dy = sy / e.pointerCount - twoY
                    val k = if (twoN == 3) "g3" else "g2"
                    if (dy > dp(90f)) act(gi(k + "_down", if (twoN == 3) 0 else 2), k + "_down") else if (dy < -dp(90f)) act(gi(k + "_up", 0), k + "_up")
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> twoOn = false
            }
        }
        return super.dispatchTouchEvent(e)
    }
    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("orion", 0); lay = Layout(sp); lay.load()
        wm = AppWidgetManager.getInstance(this); host = AppWidgetHost(this, 1024)
        applyImmersive()
        root = FrameLayout(this)
        root.setOnApplyWindowInsetsListener { v, i -> v.setPadding(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom); i }

        pages = LinearLayout(this)
        pager = Pg(this).apply {
            isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; isFillViewport = true
            addView(pages, FrameLayout.LayoutParams(-2, -1))
            xform = { applyXform() }; onPage = { updDots() }
        }
        val gd0 = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { act(gi("g_dbl", 3), "g_dbl"); return true }
            override fun onLongPress(e: MotionEvent) { act(gi("g_long", 10), "g_long") }
        })
        pager.setOnTouchListener { _, e -> gd0.onTouchEvent(e); false }
        pager.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ ->
            val w = r - l; val h = bt - t
            if (w > 0 && h > 0 && (w != lastW || h != lastH)) { lastW = w; lastH = h; pager.post { renderHome(false) } }
        }
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(4f), 0, dp(2f)) }
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; background = glass(dp(32f).toFloat(), -50); setPadding(dp(10f), dp(8f), dp(10f), dp(8f)); visibility = View.GONE }
        dock.setOnDragListener(dockDrag())
        strip = LinearLayout(this).apply { visibility = View.GONE; setPadding(dp(10f), dp(6f), dp(10f), dp(6f)) }
        listOf(
            zone("Убрать") { removeDragged() },
            zone("О приложении") { val p = dragPkg(); if (p != null) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))) },
            zone("Удалить") { val p = dragPkg(); if (p != null) startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p"))) },
            zone("Скрыть") { val p = dragPkg(); if (p != null) { removeDragged(); hideApp(p) } }
        ).forEach { strip.addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) }) }
        buildDrawer()

        sbIcon = ImageView(this); sbText = tv("Поиск приложений, контактов и сайтов", 16f)
        sbar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18f), 0, dp(18f), 0); elevation = dp(3f).toFloat(); setOnClickListener { openDrawer(true) }; setOnLongClickListener { act(gi("g_sbl", 15), "g_sbl"); true } }
        sbar.addView(sbIcon, LinearLayout.LayoutParams(dp(22f), dp(22f)))
        sbar.addView(sbText.apply { setPadding(dp(14f), 0, 0, 0); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        sbar.visibility = if (gb("sbarOn", true)) View.VISIBLE else View.GONE
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f)); col.addView(dots, LinearLayout.LayoutParams(-1, -2))
        col.addView(dock, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4f); bottomMargin = dp(8f) })
        col.addView(sbar, LinearLayout.LayoutParams(-1, dp(52f)).apply { setMargins(dp(16f), dp(4f), dp(16f), dp(14f)) })
        root.addView(col, FrameLayout.LayoutParams(-1, -1)); root.addView(drawer, FrameLayout.LayoutParams(-1, -1)); root.addView(strip, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)

        flingDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                val th = gi("gsens", 1800)
                if (Math.abs(vy) < Math.abs(vx) * 1.4f) {
                    if (drawerOpen || Math.abs(vx) < th) return false
                    if (vx > 0 && curPage() == 0 && pager.scrollX <= 12) { act(gi("g_p0", 0), "g_p0"); return true }
                    if (vx < 0 && curPage() >= lay.pages - 1 && pager.scrollX >= (lay.pages - 1) * pager.width - 12) { act(gi("g_pl", 0), "g_pl"); return true }
                    return false
                }
                if (drawerOpen) { if (vy > th && !drv.canScrollVertically(-1)) { closeDrawer(false); return true }; return false }
                val onDock = a != null && dock.visibility == View.VISIBLE && inView(dock, a.rawX, a.rawY)
                if (vy < -th && onDock) { act(gi("g_dock", 9), "g_dock"); return true }
                if (vy > th) { act(gi("g_down", 1), "g_down"); return true }
                if (vy < -th) { act(gi("g_up", 9), "g_up"); return true }
                return false
            }
        })
        scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { cum = 1f; return true }
            override fun onScale(d: ScaleGestureDetector): Boolean { cum *= d.scaleFactor; return true }
            override fun onScaleEnd(d: ScaleGestureDetector) {
                if (drawerOpen) return
                if (cum < .78f) act(gi("g_pin", 10), "g_pin") else if (cum > 1.3f) act(gi("g_pout", 0), "g_pout")
            }
        })
        Notif.cb = { runOnUiThread { handler.removeCallbacks(badgeRun); handler.postDelayed(badgeRun, 400) } }
        rcv = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { load() } }
        registerReceiver(rcv, IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package") })
        applyWin(); styleBars(); load()
    }
    override fun onStart() { super.onStart(); try { host.startListening() } catch (e: Exception) {} }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (e: Exception) {} }
    override fun onDestroy() { super.onDestroy(); try { unregisterReceiver(rcv) } catch (e: Exception) {} }
    override fun onResume() { super.onResume(); applyWin(); updAlarm() }
    override fun onConfigurationChanged(c: android.content.res.Configuration) { super.onConfigurationChanged(c); styleBars(); load() }
    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (drawerOpen) closeDrawer(true) else if (curPage() != 0) goPage(0)
        drainPins()
    }
    override fun onBackPressed() { if (drawerOpen) closeDrawer(false) else if (curPage() != 0) goPage(0) }
    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rq, p, r)
        if (rq == 5 && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) { startAsyncSearch(); showResults() }
    }

    // ---------- apps / icon packs ----------
    fun packs(): List<ResolveInfo> {
        val l = ArrayList<ResolveInfo>()
        listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.anddoes.launcher.THEME", "com.gau.go.launcherex.theme").forEach { a ->
            packageManager.queryIntentActivities(Intent(a), 0).forEach { r -> if (l.none { it.activityInfo.packageName == r.activityInfo.packageName }) l.add(r) } }
        return l
    }
    fun loadPack(pkg: String): Map<String, String> {
        val m = HashMap<String, String>()
        try {
            val r = packageManager.getResourcesForApplication(pkg); val id = r.getIdentifier("appfilter", "xml", pkg)
            val xp: XmlPullParser = if (id != 0) r.getXml(id) else XmlPullParserFactory.newInstance().newPullParser().also { it.setInput(r.assets.open("appfilter.xml"), null) }
            var e = xp.eventType
            while (e != XmlPullParser.END_DOCUMENT) {
                if (e == XmlPullParser.START_TAG && xp.name == "item") {
                    val c = xp.getAttributeValue(null, "component"); val d = xp.getAttributeValue(null, "drawable")
                    if (c != null && d != null) m[c.removePrefix("ComponentInfo{").removeSuffix("}")] = d
                }
                e = xp.next()
            }
        } catch (ex: Exception) {}
        return m
    }
    fun renames(): JSONObject = try { JSONObject(gs("ren", "{}")) } catch (e: Exception) { JSONObject() }
    fun themedIcon(d: Drawable): Drawable {
        if (Build.VERSION.SDK_INT >= 33 && d is android.graphics.drawable.AdaptiveIconDrawable) {
            val mono = d.monochrome
            if (mono != null) {
                val fg = mono.mutate(); fg.setTint(cOnTonal())
                return android.graphics.drawable.AdaptiveIconDrawable(android.graphics.drawable.ColorDrawable(cTonal()), fg)
            }
        }
        return d
    }
    fun load() {
        val gen = ++loadGen
        val pack = gs("pack", ""); val themed = gb("themed", true); val ren = renames()
        Thread {
            val map = if (pack.isNotEmpty()) loadPack(pack) else emptyMap()
            val pr = if (pack.isNotEmpty()) try { packageManager.getResourcesForApplication(pack) } catch (e: Exception) { null } else null
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = packageManager.queryIntentActivities(i, 0).map {
                var icon = it.loadIcon(packageManager); var packed = false
                if (pr != null) {
                    val d = map[it.activityInfo.packageName + "/" + it.activityInfo.name]
                    if (d != null) { val id = pr.getIdentifier(d, "drawable", pack); if (id != 0) try { icon = pr.getDrawable(id, null); packed = true } catch (e: Exception) {} }
                }
                if (themed && !packed) icon = themedIcon(icon)
                val pk = it.activityInfo.packageName
                val lb = it.loadLabel(packageManager).toString()
                val t = try { packageManager.getPackageInfo(pk, 0).firstInstallTime } catch (e: Exception) { 0L }
                App(pk, it.activityInfo.name, ren.optString(pk, lb), icon, lb, t)
            }
            runOnUiThread { if (gen == loadGen) { apps = list; afterLoad(0) } }
        }.start()
    }
    fun afterLoad(tries: Int) {
        if (pager.height == 0 && tries < 40) { handler.postDelayed({ afterLoad(tries + 1) }, 50); return }
        val first = !lay.has()
        if (first) seed()
        if (apps.isNotEmpty()) {
            val known = apps.map { it.pkg }.toSet()
            val dead = lay.items.filter { it.type == "app" && it.data !in known }
            if (dead.isNotEmpty()) { lay.items.removeAll(dead.toSet()); lay.save() }
            val dk = dockList().filter { it in known }
            if (dk.size != dockList().size) sp.edit().putString("dock", dk.joinToString(",")).apply()
            if (first || gb("autofill", true)) autoFill()
        }
        renderHome(false); rebuildDock(); showResults(); drainPins()
    }
    fun byName(l: List<App>): List<App> = l.sortedWith(Comparator<App> { a, b -> coll.compare(a.label, b.label) })
    fun autoFill() {
        val cols = gi("hcols", 4); val rows = rowsN()
        val placed = HashSet<String>()
        lay.items.forEach { if (it.type == "app") placed.add(it.data) }
        val f = folders(); fnames(f).forEach { n -> val a = f.getJSONArray(n); for (i in 0 until a.length()) placed.add(a.getString(i)) }
        placed.addAll(dockList()); val hid = hidden()
        val fresh = byName(apps.filter { it.pkg !in placed && it.pkg !in hid })
        if (fresh.isEmpty()) return
        fresh.forEach { a -> lay.place(Item("app", a.pkg, 0, 0, 0), cols, rows) }
        lay.save()
    }
    fun defaultPkg(i: Intent): String? = try { packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName } catch (e: Exception) { null }
    fun seed() {
        val cols = gi("hcols", 4)
        lay.items.clear(); lay.pages = 1
        lay.items.add(Item("clock", "", 0, 0, 0, cols, 2))
        val dk = listOfNotNull(defaultPkg(Intent(Intent.ACTION_DIAL)), defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))), defaultPkg(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)))
            .filter { p -> apps.any { it.pkg == p } }.distinct()
        if (gs("dock", "").isEmpty() && dk.isNotEmpty()) sp.edit().putString("dock", dk.joinToString(",")).apply()
        lay.save()
    }
    fun appOf(p: String): App? = apps.find { it.pkg == p }
    fun sorted(l: List<App>): List<App> = when (gi("sort", 0)) {
        1 -> byName(l).reversed()
        2 -> l.sortedByDescending { it.installed }
        3 -> l.sortedByDescending { hcount(it.pkg) }
        else -> byName(l)
    }
    fun folders(): JSONObject {
        val c = fcache; if (c != null) return c
        val j = try { JSONObject(gs("f", "{}")) } catch (e: Exception) { JSONObject() }
        fcache = j; return j
    }
    fun fnames(f: JSONObject) = f.keys().asSequence().toList()
    fun saveFolders(j: JSONObject) { fcache = j; sp.edit().putString("f", j.toString()).apply() }
    fun stripPkg(f: JSONObject, p: String) {
        fnames(f).forEach { n -> val a = f.getJSONArray(n); val na = JSONArray(); for (i in 0 until a.length()) if (a.getString(i) != p) na.put(a.getString(i)); if (na.length() == 0) f.remove(n) else f.put(n, na) }
    }
    fun putF(n: String, p: String) { val f = folders(); stripPkg(f, p); val j = f.optJSONArray(n) ?: JSONArray(); j.put(p); f.put(n, j); saveFolders(f) }
    fun hideApp(p: String) {
        val h = hidden(); h.add(p); sp.edit().putStringSet("hid", h).apply()
        lay.items.removeAll(lay.items.filter { it.type == "app" && it.data == p }.toSet()); lay.save()
        removeDock(p); showResults(); renderHome(false)
    }
    fun unhide(p: String) {
        val h = hidden(); h.remove(p); sp.edit().putStringSet("hid", h).apply()
        if (gb("autofill", true)) autoFill()
        renderHome(false); showResults()
    }
    // ---------- history (recent actions) ----------
    fun hist(): JSONObject {
        val c = hcache; if (c != null) return c
        val j = try { JSONObject(gs("hist", "{}")) } catch (e: Exception) { JSONObject() }
        hcache = j; return j
    }
    fun hcount(p: String): Int = hist().optJSONArray(p)?.optInt(0) ?: 0
    fun record(p: String) {
        val h = hist(); val n = (h.optJSONArray(p)?.optInt(0) ?: 0) + 1
        h.put(p, JSONArray().put(n).put(System.currentTimeMillis())); sp.edit().putString("hist", h.toString()).apply()
    }
    fun recentApps(): List<App> {
        val h = hist(); val hid = hidden()
        return h.keys().asSequence().toList().sortedByDescending { h.getJSONArray(it).optLong(1) }.mapNotNull { p -> appOf(p) }.filter { it.pkg !in hid }.take(8)
    }
    fun recentQ(): List<String> = gs("rq", "").split("\n").filter { it.isNotBlank() }
    fun addQ(t: String) { sp.edit().putString("rq", (listOf(t) + recentQ().filter { it != t }).take(8).joinToString("\n")).apply() }
    fun clearHistory() { sp.edit().remove("hist").remove("rq").apply(); hcache = null; showResults() }
    // ---------- home rendering ----------
    fun animIn(v: View, n: Int) {
        val st = gi("ianim", 1); if (st == 0) return
        v.alpha = 0f
        if (st == 1) { v.scaleX = .75f; v.scaleY = .75f } else v.translationY = dp(26f).toFloat()
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setStartDelay(minOf(n * 14, 240).toLong()).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }
    fun newGrid(p: Int, cols: Int, rows: Int): Grid { val g = Grid(this); g.cols = cols; g.rows = rows; g.setOnDragListener(pageDrag(g, p)); return g }
    fun renderHome(anim: Boolean) {
        if (!this::pager.isInitialized) return
        val cols = gi("hcols", 4); val rows = rowsN()
        lay.clamp(cols, rows)
        val keep = curPage()
        pages.removeAllViews()
        val pw = pageW(); val cw = pw / cols; val chh = pageH() / rows
        var n = 0
        for (p in 0 until lay.pages) {
            val g = newGrid(p, cols, rows)
            lay.items.filter { it.page == p }.forEach { m ->
                val v = itemView(m, cw, chh)
                if (v != null) { g.addView(v); if (anim) animIn(v, n++) }
            }
            pages.addView(g, LinearLayout.LayoutParams(pw, -1))
        }
        pager.post { pager.scrollTo(minOf(keep, lay.pages - 1) * pager.width, 0); applyXform(); updDots() }
        updDots()
    }
    fun itemView(m: Item, cw: Int, ch: Int): View? {
        val v: View? = when (m.type) {
            "app" -> { val a = appOf(m.data); if (a == null) null else appCell(a, cw, ch, m, Notif.counts[a.pkg] ?: 0) }
            "folder" -> folderCell(m, cw, ch)
            "widget" -> widgetView(m, cw, ch)
            "clock" -> clockView(m)
            "shortcut" -> shortcutCell(m, cw, ch)
            "search" -> searchPill(m)
            else -> null
        }
        v?.tag = m
        return v
    }
    fun touchFx(v: View) {
        v.setOnTouchListener { vw, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> vw.animate().scaleX(.92f).scaleY(.92f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> vw.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }
    fun label(t: String): TextView = TextView(this).apply {
        val dk = gb("dark", false)
        text = t; textSize = gi("lbl", 12).toFloat(); setTextColor(if (dk) 0xFF1D1B20.toInt() else Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        if (!dk) setShadowLayer(3f, 0f, 1f, 0x99000000.toInt())
    }
    fun appCell(a: App, cw: Int, ch: Int, m: Item?, count: Int): LinearLayout {
        val st = gi("gstyle", 0)
        val labels = gb("labels", true) && st != 3
        var s = dp(iconDp()); if (st == 2) s = (s * .9f).toInt()
        s = minOf(s, maxOf(dp(24f), minOf(cw - dp(8f), (ch * (if (labels) .64f else .86f)).toInt())))
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(2f), 0, dp(2f)); background = ripple() }
        if (st == 1) v.background = InsetDrawable(glass(dp(20f).toFloat(), -60), dp(3f))
        val box = FrameLayout(this); v.addView(box, LinearLayout.LayoutParams(s, s))
        box.addView(iconView(a.icon, s))
        if (count > 0 && gb("badges", true)) box.addView(badge(count))
        if (labels) v.addView(label(a.label), LinearLayout.LayoutParams(maxOf(s, cw - dp(6f)), -2).apply { topMargin = dp(3f) })
        v.setOnClickListener { launch(a, box) }
        v.setOnLongClickListener { if (m != null) beginDrag(v, m, null, null) else appMenu(a, null, false); true }
        return v
    }
    fun folderCell(m: Item, cw: Int, ch: Int): View {
        val st = gi("gstyle", 0); val labels = gb("labels", true) && st != 3
        var s = dp(iconDp()); if (st == 2) s = (s * .9f).toInt()
        s = minOf(s, maxOf(dp(24f), minOf(cw - dp(8f), (ch * (if (labels) .62f else .86f)).toInt())))
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(2f), 0, dp(2f)) }
        val box = FrameLayout(this); v.addView(box, LinearLayout.LayoutParams(s, s))
        box.background = glass(s * gi("rad", 28) / 100f, 25)
        val gr = GridLayout(this).apply { columnCount = 3; rowCount = 3; setPadding(s / 12, s / 12, s / 12, s / 12) }
        val pk = folders().optJSONArray(m.data) ?: JSONArray(); var count = 0; var shown = 0
        for (i in 0 until pk.length()) {
            val a = appOf(pk.getString(i)) ?: continue; count += Notif.counts[a.pkg] ?: 0
            if (shown++ < 9) gr.addView(ImageView(this).apply { setImageDrawable(a.icon) }, GridLayout.LayoutParams().apply { width = (s * .26f).toInt(); height = width; setMargins(s / 50, s / 50, s / 50, s / 50) })
        }
        box.addView(gr, FrameLayout.LayoutParams(s, s))
        if (count > 0 && gb("badges", true)) box.addView(badge(count))
        if (labels) v.addView(label(m.data), LinearLayout.LayoutParams(maxOf(s, cw - dp(6f)), -2))
        v.background = ripple()
        v.setOnClickListener { openFolder(m.data) }
        v.setOnLongClickListener { beginDrag(v, m, null, null); true }
        return v
    }
    fun widgetView(m: Item, cw: Int, ch: Int): View? {
        val id = m.data.toIntOrNull() ?: return null
        val info = wm.getAppWidgetInfo(id) ?: return null
        val hv = wcache[id] ?: host.createView(this, id, info).also { it.setAppWidget(id, info); wcache[id] = it }
        (hv.parent as? ViewGroup)?.removeView(hv)
        val d = resources.displayMetrics.density
        val w = (cw * m.sx / d).toInt(); val h = (ch * m.sy / d).toInt()
        try { hv.updateAppWidgetSize(null, w, h, w, h) } catch (e: Exception) {}
        hv.setOnLongClickListener { widgetMenu(m, hv); true }
        return hv
    }
    fun clockView(m: Item): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL or Gravity.START; setPadding(dp(22f), 0, dp(22f), 0)
        val sh = 0x66000000
        addView(TextClock(this@MainActivity).apply { format12Hour = "h:mm"; format24Hour = "H:mm"; textSize = 60f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setShadowLayer(10f, 0f, 2f, sh) })
        addView(TextClock(this@MainActivity).apply { format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"; textSize = 17f; setTextColor(0xF2FFFFFF.toInt()); setShadowLayer(8f, 0f, 1f, sh) })
        addView(TextView(this@MainActivity).apply { textSize = 14f; setTextColor(0xCCFFFFFF.toInt()); setShadowLayer(8f, 0f, 1f, sh); alarmTv = this; updAlarm() })
        setOnClickListener { act(gi("g_clock", 21), "g_clock") }
        setOnLongClickListener { beginDrag(this, m, null, null); true }
    }
    fun searchPill(m: Item): View = TextView(this).apply {
        text = "Поиск"; textSize = 16f; setTextColor(cText2()); gravity = Gravity.CENTER_VERTICAL
        background = InsetDrawable(rr(withAlpha(cContainer(), 0xEE), dp(26f).toFloat()), dp(8f)); setPadding(dp(28f), 0, dp(28f), 0)
        setOnClickListener { openDrawer(true) }
        setOnLongClickListener { beginDrag(this, m, null, null); true }
    }
    fun iconView(dr: Drawable, s: Int): View {
        val iv = ImageView(this).apply {
            setImageDrawable(dr)
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * gi("rad", 28) / 100f) } }
            clipToOutline = true
        }
        if (!gb("tile", false)) { iv.layoutParams = FrameLayout.LayoutParams(s, s); return iv }
        val f = FrameLayout(this); val p = s / 7
        f.background = glass(s * gi("rad", 28) / 100f, 40)
        f.addView(iv, FrameLayout.LayoutParams(s - p * 2, s - p * 2, Gravity.CENTER)); f.layoutParams = FrameLayout.LayoutParams(s, s)
        return f
    }
    fun badge(n: Int): View = TextView(this).apply {
        text = if (n > 99) "99+" else "$n"; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(5f), 0, dp(5f), 0); minWidth = dp(18f); minHeight = dp(18f)
        background = GradientDrawable().apply { cornerRadius = dp(10f).toFloat(); setColor(0xFFFF3B30.toInt()) }
        layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.TOP)
    }

    // ---------- page effects / indicator ----------
    fun applyXform() {
        val w = pager.width.toFloat(); if (w <= 0f) return
        parallax()
        val st = gi("xform", 1); val dm = resources.displayMetrics.density
        for (i in 0 until pages.childCount) {
            val v = pages.getChildAt(i)
            val pos = (v.left - pager.scrollX) / w; val ap = Math.abs(pos)
            var a = 1f; var sc = 1f; var rot = 0f; var tx = 0f
            v.pivotX = v.width / 2f; v.pivotY = v.height / 2f; v.cameraDistance = 9000f * dm
            if (ap < 1f) when (st) {
                2 -> { sc = 1f - .25f * ap; a = 1f - .6f * ap }
                3 -> { v.pivotX = if (pos < 0) v.width.toFloat() else 0f; rot = -60f * pos }
                4 -> if (pos > 0) { tx = -pos * w; sc = .85f + .15f * (1f - ap); a = 1f - ap }
                5 -> { rot = -75f * pos; a = 1f - .8f * ap }
                6 -> a = 1f - ap
            }
            v.alpha = a; v.scaleX = sc; v.scaleY = sc; v.rotationY = rot; v.translationX = tx
        }
    }
    fun updDots() {
        if (!this::dots.isInitialized) return
        dots.removeAllViews()
        val n = lay.pages; val cur = curPage().coerceIn(0, maxOf(0, n - 1)); val st = gi("dotst", 0)
        if (n <= 1 || st == 3) return
        if (st == 2) { dots.addView(TextView(this).apply { text = "${cur + 1} / $n"; textSize = 13f; setTextColor(Color.WHITE) }); return }
        for (i in 0 until n) {
            val on = i == cur
            val w = if (st == 1) dp(if (on) 22f else 8f) else dp(if (on) 8f else 6f); val h = if (st == 1) dp(3f) else w
            dots.addView(View(this).apply { background = rr(if (on) Color.WHITE else 0x66FFFFFF, dp(6f).toFloat()) },
                LinearLayout.LayoutParams(w, h).apply { setMargins(dp(3f), 0, dp(3f), 0) })
        }
    }
    // ---------- dock ----------
    fun rebuildDock() {
        dock.removeAllViews(); dock.minimumHeight = 0; dock.minimumWidth = 0
        val ps = dockList(); val s = dp(minOf(iconDp(), 64f))
        ps.forEach { p ->
            val a = appOf(p) ?: return@forEach
            val v = iconView(a.icon, s)
            v.layoutParams = LinearLayout.LayoutParams(s, s).apply { setMargins(dp(8f), dp(6f), dp(8f), dp(6f)) }
            v.setOnClickListener { launch(a, v) }
            v.setOnLongClickListener { beginDrag(v, null, null, p); true }
            dock.addView(v)
        }
        dock.visibility = if (dock.childCount == 0) View.GONE else View.VISIBLE
    }
    fun addDock(p: String) { val l = dockList().filter { it != p }.toMutableList(); l.add(p); while (l.size > 5) l.removeAt(0); sp.edit().putString("dock", l.joinToString(",")).apply(); rebuildDock() }
    fun removeDock(p: String) {
        sp.edit().putString("dock", dockList().filter { it != p }.joinToString(",")).apply(); rebuildDock()
        if (gb("autofill", true) && apps.isNotEmpty()) { autoFill(); handler.post { renderHome(false) } }
    }

    // ---------- drag and drop (free placement) ----------
    fun dragPkg(): String? {
        val di = dragItem; val da = dragApp
        return if (di != null) (if (di.type == "app") di.data else null) else if (da != null) da.pkg else dragDock
    }
    fun beginDrag(v: View, item: Item?, app: App?, dockPkg: String?) {
        if (gb("lock", false) && item != null) { showMenuFor(item); return }
        dragItem = item; dragApp = app; dragDock = dockPkg; dragging = true
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        strip.visibility = View.VISIBLE
        dock.visibility = View.VISIBLE; dock.minimumHeight = dp(76f); dock.minimumWidth = dp(220f)
        if (lay.pages < 8 && lay.onPage(lay.pages - 1).isNotEmpty()) {
            lay.pages++; spare = true
            pages.addView(newGrid(lay.pages - 1, gi("hcols", 4), rowsN()), LinearLayout.LayoutParams(pageW(), -1))
            updDots()
        }
        if (item != null) v.alpha = .3f
        if (drawerOpen) drawer.visibility = View.INVISIBLE
        v.startDragAndDrop(ClipData.newPlainText("o", "o"), View.DragShadowBuilder(v), null, 0)
    }
    fun endDrag() {
        if (!dragging) return
        dragging = false; dragItem = null; dragApp = null; dragDock = null; stopEdge()
        handler.post {
            strip.visibility = View.GONE
            if (spare) { spare = false; while (lay.pages > 1 && lay.items.none { it.page == lay.pages - 1 }) lay.pages--; lay.save() }
            if (drawerOpen) closeDrawer(true)
            renderHome(false); rebuildDock()
        }
    }
    fun pageDrag(g: Grid, p: Int) = object : View.OnDragListener {
        override fun onDrag(v: View, e: DragEvent): Boolean {
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> return dragging
                DragEvent.ACTION_DRAG_ENTERED, DragEvent.ACTION_DRAG_LOCATION -> { hilite(g, e.x, e.y); edge(g, e.x) }
                DragEvent.ACTION_DRAG_EXITED -> { g.hl = null; g.invalidate(); stopEdge() }
                DragEvent.ACTION_DROP -> { stopEdge(); g.hl = null; g.invalidate(); onDrop(p, g, e.x, e.y); return true }
                DragEvent.ACTION_DRAG_ENDED -> { stopEdge(); g.hl = null; g.invalidate(); endDrag() }
            }
            return true
        }
    }
    fun spanOrigin(g: Grid, x: Float, y: Float): IntArray {
        val c = g.cell(x, y); val di = dragItem; val sx = di?.sx ?: 1; val sy = di?.sy ?: 1
        return intArrayOf((c[0] - (sx - 1) / 2).coerceIn(0, maxOf(0, g.cols - sx)), (c[1] - (sy - 1) / 2).coerceIn(0, maxOf(0, g.rows - sy)), sx, sy)
    }
    fun hilite(g: Grid, x: Float, y: Float) {
        val o = spanOrigin(g, x, y); val cw = (g.width / g.cols).toFloat(); val ch = (g.height / g.rows).toFloat()
        g.hl = RectF(o[0] * cw + 4, o[1] * ch + 4, (o[0] + o[2]) * cw - 4, (o[1] + o[3]) * ch - 4); g.invalidate()
    }
    fun edge(g: Grid, x: Float) {
        val d = if (x < dp(40f)) -1 else if (x > g.width - dp(40f)) 1 else 0
        if (d != edgeDir) { handler.removeCallbacks(edgeRun); edgeDir = d; if (d != 0) handler.postDelayed(edgeRun, 600) }
    }
    fun stopEdge() { handler.removeCallbacks(edgeRun); edgeDir = 0 }
    fun edgeFlip() { if (edgeDir == 0) return; goPage(curPage() + edgeDir); handler.postDelayed(edgeRun, 900) }
    fun onDrop(p: Int, g: Grid, x: Float, y: Float) {
        val o = spanOrigin(g, x, y); val col = o[0]; val row = o[1]; val sx = o[2]; val sy = o[3]
        val di = dragItem; val da = dragApp; val dd = dragDock; val pkg = dragPkg()
        val c = g.cell(x, y); val tgt = lay.at(p, c[0], c[1], di)
        if (di != null && di.page == p && di.col == col && di.row == row) { handler.post { showMenuFor(di) }; return }
        if (pkg != null && sx == 1 && sy == 1 && tgt != null && (tgt.type == "app" || tgt.type == "folder")) {
            if (tgt.type == "app" && tgt.data == pkg) { toast("Уже здесь"); return }
            if (tgt.type == "folder") { putF(tgt.data, pkg); if (di != null) lay.items.remove(di); if (dd != null) removeDock(pkg); lay.save(); handler.post { renderHome(false) } }
            else ask("Название папки", "Папка") { n ->
                val nm = n.ifBlank { "Папка" }; putF(nm, tgt.data); putF(nm, pkg); tgt.type = "folder"; tgt.data = nm
                if (di != null) lay.items.remove(di); if (dd != null) removeDock(pkg); lay.save(); renderHome(false)
            }
            return
        }
        if (!lay.fits(p, col, row, sx, sy, g.cols, g.rows, di)) { toast("Здесь нет места"); return }
        if (di != null) { di.page = p; di.col = col; di.row = row }
        else if (pkg != null) { lay.items.add(Item("app", pkg, p, col, row)); if (dd != null) removeDock(pkg) }
        else if (da != null) lay.items.add(Item("app", da.pkg, p, col, row))
        lay.save(); handler.post { renderHome(false) }
    }
    fun dockDrag() = object : View.OnDragListener {
        override fun onDrag(v: View, e: DragEvent): Boolean {
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> return dragging && dragPkg() != null
                DragEvent.ACTION_DRAG_ENTERED -> v.alpha = .6f
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> v.alpha = 1f
                DragEvent.ACTION_DROP -> {
                    v.alpha = 1f
                    val pkg = dragPkg() ?: return false
                    if (dragDock != null) { val a = appOf(pkg); if (a != null) handler.post { appMenu(a, null, true) } }
                    else { addDock(pkg); val di = dragItem; if (di != null) { lay.items.remove(di); lay.save() } }
                    return true
                }
            }
            return true
        }
    }
    fun zone(t: String, run: () -> Unit): TextView = tv(t, 13f, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(6f), dp(14f), dp(6f), dp(14f)); background = rr(withAlpha(cContainer(), 0xF2), dp(20f).toFloat()); elevation = dp(4f).toFloat()
        setOnDragListener { v, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_ENTERED -> { v.alpha = .7f; v.scaleX = 1.06f; v.scaleY = 1.06f }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f }
                DragEvent.ACTION_DROP -> { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f; run() }
            }
            true
        }
    }
    fun removeDragged() {
        val di = dragItem; val dd = dragDock
        if (di != null) {
            if (di.type == "app") hideApp(di.data)
            else {
                if (di.type == "folder") { val f = folders(); f.remove(di.data); saveFolders(f) }
                if (di.type == "widget") { val id = di.data.toIntOrNull(); if (id != null) { host.deleteAppWidgetId(id); wcache.remove(id) } }
                lay.items.remove(di); lay.save()
            }
        }
        if (dd != null) removeDock(dd)
    }
    // ---------- menus ----------
    fun menu(t: String, o: List<CharSequence>, cb: (Int) -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24f), dp(24f), dp(24f), dp(10f)) }
        c.addView(tv(t, 22f).apply { setPadding(0, 0, 0, dp(10f)) })
        var dg: Dialog? = null
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        o.forEachIndexed { i, x -> list.addView(tv(x.toString(), 16f).apply { setPadding(dp(8f), dp(14f), dp(8f), dp(14f)); background = ripple(); setOnClickListener { dg?.dismiss(); cb(i) } }) }
        val h = minOf(o.size * dp(50f), (resources.displayMetrics.heightPixels * .6).toInt())
        c.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, h))
        c.addView(tv("Отмена", 14f, true).apply { setTextColor(cAccent()); gravity = Gravity.END; setPadding(dp(12f), dp(14f), dp(12f), dp(8f)); setOnClickListener { dg?.dismiss() } }, LinearLayout.LayoutParams(-1, -2))
        dg = gd(c)
    }
    fun ask(t: String, def: String, cb: (String) -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24f), dp(24f), dp(24f), dp(10f)) }
        c.addView(tv(t, 22f))
        val et = EditText(this).apply { setText(def); setTextColor(cText()); setSingleLine(true); setSelection(def.length); backgroundTintList = android.content.res.ColorStateList.valueOf(cAccent()) }
        c.addView(et, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12f) })
        var dg: Dialog? = null
        val r = LinearLayout(this).apply { gravity = Gravity.END }
        r.addView(tv("Отмена", 14f, true).apply { setTextColor(cAccent()); setPadding(dp(14f), dp(16f), dp(14f), dp(8f)); setOnClickListener { dg?.dismiss() } })
        r.addView(tv("OK", 14f, true).apply { setTextColor(cAccent()); setPadding(dp(14f), dp(16f), dp(14f), dp(8f)); setOnClickListener { dg?.dismiss(); cb(et.text.toString()) } })
        c.addView(r, LinearLayout.LayoutParams(-1, -2))
        val d = gd(c); dg = d
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
    fun showMenuFor(m: Item) {
        when (m.type) {
            "app" -> { val a = appOf(m.data); if (a != null) appMenu(a, m, false) }
            "folder" -> folMenu(m.data, m)
            "widget" -> { val id = m.data.toIntOrNull(); val hv = if (id != null) wcache[id] else null; if (hv != null) widgetMenu(m, hv) }
            else -> {
                val ttl = when (m.type) {
                    "clock" -> "Часы"
                    "shortcut" -> "Ярлык"
                    else -> "Строка поиска"
                }
                menu(ttl, listOf("Убрать")) { lay.items.remove(m); lay.save(); renderHome(false) }
            }
        }
    }
    fun shortcutsOf(pkg: String): List<Sc> {
        val r = ArrayList<Sc>()
        if (Build.VERSION.SDK_INT < 25) return r
        try {
            val la = getSystemService(LauncherApps::class.java)
            val qy = LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
            val me = android.os.Process.myUserHandle()
            la.getShortcuts(qy, me)?.take(4)?.forEach { s ->
                r.add(Sc((s.shortLabel ?: s.id).toString()) { try { la.startShortcut(pkg, s.id, null, null, me) } catch (e: Exception) {} })
            }
        } catch (e: Exception) {}
        return r
    }
    fun appMenu(a: App, m: Item?, fromDock: Boolean) {
        val names = ArrayList<CharSequence>(); val runs = ArrayList<() -> Unit>()
        fun o(t: String, r: () -> Unit) { names.add(t); runs.add(r) }
        shortcutsOf(a.pkg).forEach { s -> o("> " + s.label) { s.run() } }
        o("О приложении") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))) }
        o("Удалить") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))) }
        o("Переименовать") { ask("Название", a.label) { n -> val r = renames(); if (n.isBlank() || n == a.orig) r.remove(a.pkg) else r.put(a.pkg, n.trim()); sp.edit().putString("ren", r.toString()).apply(); load() } }
        o("Скрыть") { hideApp(a.pkg) }
        if (fromDock || dockList().contains(a.pkg)) o("Убрать из дока") { removeDock(a.pkg) } else o("В док") { addDock(a.pkg) }
        if (m == null && !fromDock && lay.items.none { it.type == "app" && it.data == a.pkg }) o("На главный экран") { addToHome(a.pkg) }
        menu(a.label, names) { i -> runs[i]() }
    }
    fun folMenu(n: String, m: Item?) = menu(n, listOf("Переименовать", "Удалить папку")) {
        val f = folders()
        if (it == 0) ask("Название папки", n) { nn ->
            val a = f.remove(n); val nm = if (nn.isNotBlank()) nn else n; if (a != null) f.put(nm, a); saveFolders(f)
            lay.items.filter { x -> x.type == "folder" && x.data == n }.forEach { x -> x.data = nm }; lay.save(); renderHome(false)
        } else { f.remove(n); saveFolders(f); lay.items.removeAll(lay.items.filter { x -> x.type == "folder" && x.data == n }.toSet()); lay.save(); if (gb("autofill", true)) autoFill(); renderHome(false) }
    }
    fun openFolder(n: String) {
        val pk = folders().optJSONArray(n) ?: return
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20f), dp(22f), dp(20f), dp(18f)) }
        c.addView(tv(n, 22f).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(12f)) })
        val g = GridLayout(this).apply { columnCount = 4 }; var dg: Dialog? = null
        val w = (minOf((resources.displayMetrics.widthPixels * .92).toInt(), dp(420f)) - dp(40f)) / 4
        for (i in 0 until pk.length()) {
            val a = appOf(pk.getString(i)) ?: continue
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6f), 0, dp(6f)); background = ripple() }
            val sz = dp(minOf(iconDp(), 60f))
            cell.addView(iconView(a.icon, sz), LinearLayout.LayoutParams(sz, sz))
            cell.addView(tv(a.label, 11f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(w - dp(6f), -2))
            cell.setOnClickListener { dg?.dismiss(); launch(a, cell) }
            cell.setOnLongClickListener { dg?.dismiss(); val f = folders(); stripPkg(f, a.pkg); saveFolders(f); addToHome(a.pkg); true }
            g.addView(cell, GridLayout.LayoutParams().apply { width = w })
        }
        c.addView(g); c.addView(tv("Зажмите приложение, чтобы достать его из папки", 12f).apply { setTextColor(cText2()); gravity = Gravity.CENTER; setPadding(0, dp(10f), 0, 0) })
        dg = gd(c)
    }
    fun addToHome(pkg: String) {
        val m = Item("app", pkg, curPage(), 0, 0); lay.place(m, gi("hcols", 4), rowsN()); lay.save(); renderHome(false); toast("Добавлено на экран"); if (drawerOpen) closeDrawer(true)
    }
    fun homeMenu() {
        val o = listOf("Виджеты", "Часы", "Обои", "Новая страница", "Удалить страницу", "Настройки")
        menu("Главный экран", o) { i ->
            when (i) {
                0 -> addWidget(); 1 -> addBuiltin("clock", gi("hcols", 4), 2)
                2 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
                3 -> { lay.pages++; lay.save(); renderHome(false); pager.post { goPage(lay.pages - 1) } }
                4 -> delPage(curPage())
                5 -> settings()
            }
        }
    }
    fun addBuiltin(type: String, sx: Int, sy: Int) {
        val m = Item(type, "", curPage(), 0, 0, sx, sy); lay.place(m, gi("hcols", 4), rowsN()); lay.save(); renderHome(true)
    }
    fun delPage(p: Int) {
        if (lay.pages <= 1) { toast("Это единственная страница"); return }
        val n = lay.onPage(p).size
        menu("Удалить страницу ${p + 1}? Элементов: $n", listOf("Удалить", "Отмена")) { i ->
            if (i == 0) {
                lay.onPage(p).filter { it.type == "widget" }.forEach { w -> val id = w.data.toIntOrNull(); if (id != null) { host.deleteAppWidgetId(id); wcache.remove(id) } }
                lay.items.removeAll(lay.onPage(p).toSet()); lay.items.filter { it.page > p }.forEach { it.page-- }; lay.pages--; lay.save()
                if (gb("autofill", true)) autoFill(); renderHome(false)
            }
        }
    }
    // ---------- widgets ----------
    fun cfgW(id: Int) { val info = wm.getAppWidgetInfo(id); if (info?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, 2, null) else placeWidget(id) }
    fun addWidget() {
        fun appName(x: android.appwidget.AppWidgetProviderInfo): String = try { packageManager.getApplicationLabel(x.providerInfo.applicationInfo).toString() } catch (e: Exception) { x.provider.packageName }
        val ps = wm.installedProviders.sortedBy { (appName(it) + " " + it.loadLabel(packageManager)).lowercase() }
        menu("Виджеты", ps.map { appName(it) + " — " + it.loadLabel(packageManager) }) { i ->
            val p = ps[i]; val id = host.allocateAppWidgetId(); pendingId = id
            if (wm.bindAppWidgetIdIfAllowed(id, p.provider)) cfgW(id)
            else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), 1)
        }
    }
    fun parallax() {
        if (!gb("wpmove", true) || lay.pages < 2 || pager.width <= 0) return
        try { WallpaperManager.getInstance(this).setWallpaperOffsets(pager.windowToken, pager.scrollX.toFloat() / (pager.width * (lay.pages - 1)), 0.5f) } catch (e: Exception) {}
    }
    fun alarmText(): String {
        return try {
            val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            val t = am.nextAlarmClock?.triggerTime
            if (t == null) "" else "Будильник: " + android.text.format.DateFormat.format(if (android.text.format.DateFormat.is24HourFormat(this)) "EEE, H:mm" else "EEE, h:mm a", t)
        } catch (e: Exception) { "" }
    }
    fun updAlarm() { val t = alarmTv ?: return; val x = alarmText(); t.text = x; t.visibility = if (x.isEmpty()) View.GONE else View.VISIBLE }
    fun shortcutInfo(pkg: String, id: String): ShortcutInfo? {
        val k = "$pkg|$id"; val c = scCache[k]; if (c != null) return c
        if (Build.VERSION.SDK_INT < 25) return null
        return try {
            val la = getSystemService(LauncherApps::class.java)
            val qy = LauncherApps.ShortcutQuery().setPackage(pkg).setShortcutIds(listOf(id))
                .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
            val r = la.getShortcuts(qy, android.os.Process.myUserHandle())?.firstOrNull()
            if (r != null) scCache[k] = r
            r
        } catch (e: Exception) { null }
    }
    fun shortcutCell(m: Item, cw: Int, ch: Int): View? {
        val parts = m.data.split("|"); if (parts.size < 2) return null
        val si = shortcutInfo(parts[0], parts[1]) ?: return null
        val la = getSystemService(LauncherApps::class.java)
        val icon = (try { la.getShortcutIconDrawable(si, resources.displayMetrics.densityDpi) } catch (e: Exception) { null }) ?: return null
        val a = App(parts[0], "", (si.shortLabel ?: si.id).toString(), icon)
        val v = appCell(a, cw, ch, m, 0)
        v.setOnClickListener { try { la.startShortcut(si.getPackage(), si.id, null, null, android.os.Process.myUserHandle()) } catch (e: Exception) { toast("Не удалось открыть ярлык") } }
        return v
    }
    fun drainPins() {
        val q0 = gs("pinq", "[]"); if (q0 == "[]") return
        try {
            val a = JSONArray(q0); val cols = gi("hcols", 4); val rows = rowsN()
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); lay.place(Item("shortcut", o.getString("pkg") + "|" + o.getString("id"), curPage(), 0, 0), cols, rows) }
            lay.save()
        } catch (e: Exception) {}
        sp.edit().remove("pinq").apply(); renderHome(false); toast("Ярлык добавлен на экран")
    }
    fun placeWidget(id: Int) {
        val info = wm.getAppWidgetInfo(id) ?: return
        val cols = gi("hcols", 4); val rows = rowsN()
        val cw = pageW() / cols; val ch = pageH() / rows
        val sx = Math.ceil(info.minWidth.toDouble() / cw).toInt().coerceIn(1, cols); val sy = Math.ceil(info.minHeight.toDouble() / ch).toInt().coerceIn(1, rows)
        val m = Item("widget", id.toString(), curPage(), 0, 0, sx, sy); lay.place(m, cols, rows); lay.save(); renderHome(true)
        pager.post { goPage(m.page) }
    }
    fun widgetMenu(m: Item, hv: View) {
        menu("Виджет", listOf("Переместить", "Изменить размер", "Убрать")) { i ->
            when (i) {
                0 -> beginDrag(hv, m, null, null)
                1 -> menu("Ширина (клеток)", (1..gi("hcols", 4)).map { it.toString() }) { w ->
                    menu("Высота (клеток)", (1..rowsN()).map { it.toString() }) { h ->
                        val ox = m.sx; val oy = m.sy; m.sx = w + 1; m.sy = h + 1
                        if (!lay.fits(m.page, m.col, m.row, m.sx, m.sy, gi("hcols", 4), rowsN(), m)) { m.sx = ox; m.sy = oy; toast("Здесь нет места") } else { lay.save(); renderHome(false) }
                    }
                }
                2 -> { val id = m.data.toIntOrNull(); if (id != null) { host.deleteAppWidgetId(id); wcache.remove(id) }; lay.items.remove(m); lay.save(); renderHome(false) }
            }
        }
    }
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 1) { if (rs == RESULT_OK) cfgW(pendingId) else host.deleteAppWidgetId(pendingId) }
        else if (rq == 2) { if (rs == RESULT_OK) placeWidget(pendingId) else host.deleteAppWidgetId(pendingId) }
        else if (rq == 11 && rs == RESULT_OK) {
            val u = d?.data ?: return
            try { contentResolver.openOutputStream(u)?.use { it.write(backupJson().toByteArray()) }; toast("Копия сохранена") } catch (e: Exception) { toast("Не удалось сохранить копию") }
        } else if (rq == 12 && rs == RESULT_OK) {
            val u = d?.data ?: return
            try { applyBackup(contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }) } catch (e: Exception) { toast("Это не файл копии Orion") }
        }
    }

    // ---------- launching ----------
    fun launch(a: App, src: View?) {
        record(a.pkg)
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val st = gi("lanim", 1)
            if (st == 1 && src != null && src.width > 0) startActivity(i, ActivityOptions.makeScaleUpAnimation(src, 0, 0, src.width, src.height).toBundle())
            else if (st == 2) startActivity(i, ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
            else startActivity(i)
        } catch (e: Exception) { toast("Не удалось открыть " + a.label) }
        if (drawerOpen) closeDrawer(true)
    }

    // ---------- app drawer ----------
    fun buildDrawer() {
        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; background = rr(withAlpha(cSurface(), gi("dalpha", 235)), 0f) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16f), dp(12f), dp(16f), dp(8f)) }
        dsearch = EditText(this).apply {
            hint = "Поиск приложений, контактов и сайтов"; setHintTextColor(cText2()); setTextColor(cText()); isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = rr(cContainer(), dp(28f).toFloat()); setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    q = s.toString().trim(); showResults(); drv.scrollToPosition(0)
                    handler.removeCallbacks(searchRun); handler.postDelayed(searchRun, 250)
                }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
            setOnEditorActionListener { _, _, _ -> firstResult(); true }
        }
        top.addView(dsearch, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tv("⚙", 24f).apply { setTextColor(cText2()); setPadding(dp(14f), 0, dp(4f), 0); setOnClickListener { settings() } })
        val lm = GridLayoutManager(this, 4)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(p: Int): Int = if (p < results.size && results[p] is App && gi("dstyle", 0) == 0) 1 else lm.spanCount
        }
        drv = RecyclerView(this).apply { layoutManager = lm; clipToPadding = false; setPadding(dp(8f), 0, dp(8f), dp(24f)); adapter = dad }
        drawer.addView(top); drawer.addView(drv, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    fun focusSearch() {
        handler.postDelayed({ dsearch.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(dsearch, 0) }, 250)
    }
    fun openDrawer(focus: Boolean) {
        if (drawerOpen) { if (focus) focusSearch(); return }
        drawerOpen = true; dsearch.setText(""); q = ""; showResults(); drv.scrollToPosition(0)
        drawer.animate().cancel(); drawer.visibility = View.VISIBLE
        when (gi("danim", 0)) {
            0 -> { drawer.alpha = 0f; drawer.translationY = dp(140f).toFloat(); drawer.scaleX = 1f; drawer.scaleY = 1f; drawer.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator()).start() }
            1 -> { drawer.translationY = 0f; drawer.alpha = 0f; drawer.scaleX = .9f; drawer.scaleY = .9f; drawer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start() }
            else -> { drawer.alpha = 1f; drawer.translationY = 0f; drawer.scaleX = 1f; drawer.scaleY = 1f }
        }
        if (focus) focusSearch()
    }
    fun closeDrawer(now: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(dsearch.windowToken, 0); dsearch.clearFocus()
        drawer.animate().cancel()
        val st = gi("danim", 0)
        if (now || st == 2) { drawer.visibility = View.GONE; return }
        val an = drawer.animate().alpha(0f)
        if (st == 0) an.translationY(dp(140f).toFloat()) else an.scaleX(.9f).scaleY(.9f)
        an.setDuration(200).withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }.start()
    }
    fun firstResult() {
        val x = results.firstOrNull { it is App || it is Hit }
        if (x is App) launch(x, null) else if (x is Hit) x.run()
    }

    // ---------- search ----------
    fun calc(s: String): String? {
        if (!s.any { it.isDigit() } || !s.any { it in "+-*/x×" }) return null
        return try { val v = Calc(s).parse(); if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else String.format("%.6f", v).trimEnd('0').trimEnd('.') } catch (e: Exception) { null }
    }
    fun match(label: String, s: String): Int {
        val l = label.lowercase()
        if (l.startsWith(s)) return 3
        if (l.split(" ", "-", ".").any { it.startsWith(s) }) return 2
        if (l.contains(s)) return 1
        val ini = l.split(" ").filter { it.isNotEmpty() }.joinToString("") { it.substring(0, 1) }
        if (s.length >= 2 && ini.startsWith(s)) return 1
        return 0
    }
    fun engineName(): String = ENGINES[gi("engine", 0).coerceIn(0, ENGINES.size - 1)].first
    fun web(t: String) {
        addQ(t)
        val e = ENGINES[gi("engine", 0).coerceIn(0, ENGINES.size - 1)]
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(e.second.replace("%s", Uri.encode(t)))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ex: Exception) { toast("Браузер не найден") }
        if (drawerOpen) closeDrawer(true)
    }
    fun qk(e: String, t: String, s: String, r: () -> Unit): Hit = Hit(e, t, s, null) { closeDrawer(true); r() }
    fun sysAct(a: String): () -> Unit = { try { startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Недоступно") } }
    fun quick(): List<Hit> = listOf(
        qk("📶", "Wi-Fi", "Настройки", sysAct(Settings.ACTION_WIFI_SETTINGS)),
        qk("🔵", "Bluetooth", "Настройки", sysAct(Settings.ACTION_BLUETOOTH_SETTINGS)),
        qk("🖥", "Экран", "Настройки", sysAct(Settings.ACTION_DISPLAY_SETTINGS)),
        qk("🔊", "Звук", "Настройки", sysAct(Settings.ACTION_SOUND_SETTINGS)),
        qk("🔋", "Экономия заряда", "Настройки", sysAct(Settings.ACTION_BATTERY_SAVER_SETTINGS)),
        qk("📍", "Геолокация", "Настройки", sysAct(Settings.ACTION_LOCATION_SOURCE_SETTINGS)),
        qk("📦", "Приложения", "Настройки", sysAct(Settings.ACTION_APPLICATION_SETTINGS)),
        qk("🔦", "Фонарик", "Включить или выключить", { torch() }),
        qk("🔒", "Заблокировать экран", "Нужна служба специальных возможностей", { glob(8) }),
        qk("🧩", "Добавить виджет", "Orion", { addWidget() }),
        qk("🏠", "Меню главного экрана", "Orion", { homeMenu() }),
        qk("⚙", "Настройки Orion", "Orion", { settings() })
    )
    fun dial(n: String) { try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {} }
    fun openContact(id: Long, key: String) { try { startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.getLookupUri(id, key)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {} }
    fun searchContacts(s: String) {
        if (!gb("scont", true)) return
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            cres = listOf(Hit("📇", "Поиск по контактам", "Нажмите, чтобы разрешить доступ к контактам", null) { requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), 5) })
            cq = s; showResults(); return
        }
        Thread {
            val l = ArrayList<Hit>(); val seen = HashSet<Long>()
            try {
                contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                    Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%" + s + "%"), Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                    while (c.moveToNext() && l.size < 6) {
                        val id = c.getLong(0); if (!seen.add(id)) continue
                        val key = c.getString(1) ?: ""; val name = c.getString(2) ?: ""; val num = c.getString(3) ?: ""
                        l.add(Hit("👤", name, num + "   (удерживайте, чтобы позвонить)", { closeDrawer(true); dial(num) }) { closeDrawer(true); openContact(id, key) })
                    }
                }
            } catch (e: Exception) {}
            runOnUiThread { if (q == s) { cres = l; cq = s; showResults() } }
        }.start()
    }
    fun searchWeb(s: String) {
        if (!gb("sweb", true) || s.length < 2) return
        Thread {
            val l = ArrayList<Hit>()
            try {
                val c = URL("https://duckduckgo.com/ac/?q=" + Uri.encode(s)).openConnection() as HttpURLConnection
                c.connectTimeout = 2500; c.readTimeout = 2500
                val a = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
                for (i in 0 until minOf(5, a.length())) { val p = a.getJSONObject(i).getString("phrase"); l.add(Hit("🔎", p, engineName(), null) { web(p) }) }
            } catch (e: Exception) {}
            runOnUiThread { if (q == s) { wres = l; wq = s; showResults() } }
        }.start()
    }
    fun startAsyncSearch() {
        val s = q
        if (s.isEmpty()) { cres = emptyList(); wres = emptyList(); return }
        searchContacts(s); searchWeb(s)
    }
    fun build(s: String): List<Any> {
        val out = ArrayList<Any>(); val hid = hidden(); val vis = apps.filter { it.pkg !in hid }
        if (s.isEmpty()) {
            if (gb("recent", true)) {
                val ra = recentApps(); if (ra.isNotEmpty()) { out.add("Недавние"); out.addAll(ra) }
                val rq = recentQ()
                if (rq.isNotEmpty()) { out.add("Недавние запросы"); rq.forEach { t -> out.add(Hit("🕘", t, "Нажмите, чтобы повторить", null) { dsearch.setText(t); dsearch.setSelection(t.length) }) } }
            }
            if (gb("drawer", false)) { out.add("Все приложения"); out.addAll(sorted(vis)) }
            else {
                val fr = vis.filter { hcount(it.pkg) > 0 }.sortedByDescending { hcount(it.pkg) }.take(8)
                if (fr.isNotEmpty()) { out.add("Часто используемые"); out.addAll(fr) }
                else if (out.isEmpty()) out.add("Начните вводить: приложение, контакт или сайт")
            }
            return out
        }
        val ql = s.lowercase()
        val ap = vis.map { Pair(it, match(it.label, ql)) }.filter { it.second > 0 }.sortedWith(compareBy<Pair<App, Int>>({ -it.second }, { it.first.label.lowercase() })).map { it.first }
        if (ap.isNotEmpty()) { out.add("Приложения"); out.addAll(ap) }
        val c = calc(s)
        if (c != null) out.add(Hit("=", c, "Нажмите, чтобы скопировать", null) { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("calc", c)); toast("Скопировано: $c") })
        val qa = quick().filter { it.title.lowercase().contains(ql) }
        if (qa.isNotEmpty()) { out.add("Действия"); out.addAll(qa) }
        if (cq == s && cres.isNotEmpty()) { out.add("Контакты"); out.addAll(cres) }
        val rq = recentQ().filter { it.lowercase().contains(ql) && !it.equals(s, true) }
        if (rq.isNotEmpty()) { out.add("Недавние запросы"); rq.forEach { t -> out.add(Hit("🕘", t, "Искать снова", null) { web(t) }) } }
        out.add("Интернет")
        if (wq == s) out.addAll(wres)
        out.add(Hit("🌐", "Искать «$s»", "через " + engineName(), null) { web(s) })
        return out
    }
    fun showResults() {
        if (!this::drv.isInitialized) return
        results = build(q)
        val lm = drv.layoutManager as GridLayoutManager
        val s = dp(iconDp())
        lm.spanCount = if (gi("dstyle", 0) == 1) 1 else minOf(gi("dcols", 4), maxOf(1, (resources.displayMetrics.widthPixels / (s * 1.15f)).toInt()))
        dad.notifyDataSetChanged()
    }
    fun header(t: String): View = tv(t.uppercase(), 12f, true).apply { setTextColor(cAccent()); setPadding(dp(10f), dp(18f), 0, dp(6f)); layoutParams = FrameLayout.LayoutParams(-1, -2) }
    fun drawerCell(a: App): View {
        val cols = (drv.layoutManager as GridLayoutManager).spanCount
        val cell = appCell(a, resources.displayMetrics.widthPixels / maxOf(1, cols), dp(iconDp()) + dp(44f), null, Notif.counts[a.pkg] ?: 0)
        cell.layoutParams = FrameLayout.LayoutParams(-1, -2); return cell
    }
    fun appRow(a: App): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10f), dp(8f), dp(10f), dp(8f)); background = ripple(); layoutParams = FrameLayout.LayoutParams(-1, -2) }
        val s = dp(44f)
        r.addView(iconView(a.icon, s).also { it.layoutParams = LinearLayout.LayoutParams(s, s) })
        r.addView(tv(a.label, 16f).apply { setPadding(dp(14f), 0, 0, 0) })
        r.setOnClickListener { launch(a, r) }; r.setOnLongClickListener { appMenu(a, null, false); true }
        return r
    }
    fun hitRow(h: Hit): View {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10f), dp(8f), dp(10f), dp(8f)); background = ripple(); layoutParams = FrameLayout.LayoutParams(-1, -2) }
        val s = dp(44f)
        r.addView(tv(h.emoji, 20f).apply { gravity = Gravity.CENTER; background = rr(cTonal(), s / 2f) }, LinearLayout.LayoutParams(s, s))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14f), 0, 0, 0) }
        t.addView(tv(h.title, 16f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        if (h.sub.isNotEmpty()) t.addView(tv(h.sub, 13f).apply { setTextColor(cText2()); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        r.setOnClickListener { h.run() }; r.setOnLongClickListener { val a = h.alt; if (a != null) { a(); true } else false }
        return r
    }
    class VH(v: View) : RecyclerView.ViewHolder(v)
    inner class DAd : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = results.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH = VH(FrameLayout(p.context).apply { layoutParams = RecyclerView.LayoutParams(-1, -2) })
        override fun onBindViewHolder(h: VH, p: Int) {
            val f = h.itemView as FrameLayout; f.removeAllViews()
            val x = results[p]
            val v: View = if (x is String) header(x) else if (x is App) (if (gi("dstyle", 0) == 1) appRow(x) else drawerCell(x)) else if (x is Hit) hitRow(x) else View(this@MainActivity)
            f.addView(v)
        }
    }

    // ---------- backup ----------
    fun backupJson(): String {
        val j = JSONObject()
        sp.all.forEach { (k, v) -> if (v is Set<*>) j.put(k, JSONArray(v.toList())) else j.put(k, v) }
        return j.toString()
    }
    fun applyBackup(t: String) {
        val j = JSONObject(t); val e = sp.edit().clear()
        j.keys().forEach { k ->
            when (val v = j.get(k)) {
                is Int -> e.putInt(k, v); is Boolean -> e.putBoolean(k, v); is Double -> e.putFloat(k, v.toFloat()); is String -> e.putString(k, v)
                is JSONArray -> e.putStringSet(k, (0 until v.length()).map { v.getString(it) }.toSet())
            }
        }
        e.apply(); hcache = null; fcache = null; wcache.clear(); lay.load(); applyWin(); applyImmersive(); load(); toast("Восстановлено")
    }
    fun applyAll() {
        applyWin(); applyImmersive(); styleBars()
        if (this::sbar.isInitialized) sbar.visibility = if (gb("sbarOn", true)) View.VISIBLE else View.GONE
        if (apps.isNotEmpty() && gb("autofill", true)) autoFill()
        renderHome(false); rebuildDock(); showResults(); updDots()
    }
    fun styleBars() {
        if (!this::sbar.isInitialized) return
        sbar.background = rr(withAlpha(cContainer(), 0xEE), dp(28f).toFloat())
        sbText.setTextColor(cText2()); sbIcon.setImageDrawable(SearchIcon(cText2()))
        dock.background = glass(dp(32f).toFloat(), -50)
        drawer.background = rr(withAlpha(cSurface(), gi("dalpha", 235)), 0f)
        dsearch.background = rr(cContainer(), dp(28f).toFloat()); dsearch.setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
        dsearch.setTextColor(cText()); dsearch.setHintTextColor(cText2())
    }
    // ---------- settings ----------
    fun settings() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20f), dp(22f), dp(20f), dp(10f)) }
        c.addView(tv("Настройки", 28f).apply { setPadding(dp(4f), 0, 0, dp(6f)) })
        val ac = cAccent()
        fun sec(t: String) { c.addView(tv(t, 13f, true).apply { setTextColor(ac); setPadding(dp(4f), dp(24f), 0, dp(4f)) }) }
        fun row(t: String, s: String?, run: () -> Unit): TextView {
            val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4f), dp(12f), dp(4f), dp(12f)); background = ripple(); setOnClickListener { run() } }
            r.addView(tv(t, 16f))
            val sm = tv(s ?: "", 14f).apply { setTextColor(cText2()); if (s == null) visibility = View.GONE }
            r.addView(sm); c.addView(r); return sm
        }
        fun sw(t: String, s: String?, k: String, d: Boolean) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4f), dp(10f), dp(4f), dp(10f)); background = ripple() }
            val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tx.addView(tv(t, 16f)); if (s != null) tx.addView(tv(s, 14f).apply { setTextColor(cText2()) })
            val swv = Switch(this).apply {
                isChecked = gb(k, d)
                val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = android.content.res.ColorStateList(st, intArrayOf(cOnAccent(), cText2()))
                trackTintList = android.content.res.ColorStateList(st, intArrayOf(ac, withAlpha(cText2(), 90)))
                setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(k, v).apply(); applyLater() }
            }
            r.addView(tx, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(swv); r.setOnClickListener { swv.toggle() }; c.addView(r)
        }
        fun seek(t: String, mn: Int, mx: Int, cur: Int, set: (Int) -> Unit) {
            val l = tv("$t: $cur", 16f).apply { setPadding(dp(4f), dp(14f), 0, 0) }; c.addView(l)
            c.addView(SeekBar(this).apply {
                max = mx - mn; progress = (cur - mn).coerceIn(0, mx - mn)
                progressTintList = android.content.res.ColorStateList.valueOf(ac); thumbTintList = android.content.res.ColorStateList.valueOf(ac)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { l.text = "$t: ${p + mn}"; if (u) { set(p + mn); applyLater() } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        fun choice(t: String, k: String, o: List<String>, d: Int) {
            var sm: TextView? = null
            sm = row(t, o[gi(k, d).coerceIn(0, o.size - 1)]) { menu(t, o) { i -> sp.edit().putInt(k, i).apply(); sm?.text = o[i]; applyLater() } }
        }
        fun gest(t: String, k: String, d: Int) {
            var sm: TextView? = null
            sm = row(t, ACTS[gi(k, d).coerceIn(0, ACTS.size - 1)]) {
                menu(t, ACTS) { i ->
                    sp.edit().putInt(k, i).apply(); sm?.text = ACTS[i]
                    if (i == 14) { val l = byName(apps); menu("Какое приложение открыть?", l.map { it.label }) { j -> sp.edit().putString(k + "_app", l[j].pkg).apply() } }
                }
            }
        }

        sec("ГЛАВНЫЙ ЭКРАН")
        sw("Все приложения на экранах", "Как на новом телефоне: ящик не нужен, новые приложения появляются сами", "autofill", true)
        sw("Ящик приложений", "Свайп вверх покажет список всех приложений, а не только поиск", "drawer", false)
        sw("Строка поиска внизу", null, "sbarOn", true)
        seek("Колонок на экране", 3, 6, gi("hcols", 4)) { sp.edit().putInt("hcols", it).apply() }
        seek("Строк на экране (0 — авто)", 0, 9, gi("hrows", 0)) { sp.edit().putInt("hrows", it).apply() }
        choice("Анимация листания", "xform", XFORMS, 1)
        choice("Индикатор страниц", "dotst", listOf("Точки", "Линии", "Число", "Скрыт"), 0)
        sw("Заблокировать расположение", "Значки нельзя будет перетаскивать", "lock", false)
        sw("Скрыть строку состояния", null, "hidebar", false)
        sw("Движение обоев", "Обои плавно сдвигаются при листании страниц", "wpmove", true)
        row("Добавить виджет", null) { addWidget() }
        row("Новая страница", null) { lay.pages++; lay.save(); renderHome(false) }
        row("Удалить текущую страницу", null) { delPage(curPage()) }
        row("Сбросить расположение", "Все приложения заново по алфавиту") {
            menu("Сбросить расположение?", listOf("Сбросить", "Отмена")) { i ->
                if (i == 0) { sp.edit().remove("home").remove("f").apply(); fcache = null; lay.load(); wcache.clear(); afterLoad(0) }
            }
        }

        sec("ЗНАЧКИ")
        sw("Тематические значки", "Цвета значков подстраиваются под обои (Android 13+)", "themed", true)
        seek("Размер значков", 40, 80, iconDp().toInt()) { sp.edit().putFloat("iconf", it.toFloat()).apply() }
        choice("Стиль сетки", "gstyle", listOf("Классический", "Плитки", "Компактный", "Без подписей"), 0)
        sw("Плитки под значками", null, "tile", false)
        sw("Подписи под значками", null, "labels", true)
        sw("Тёмные подписи", "Для светлых обоев", "dark", false)
        seek("Размер подписей", 10, 16, gi("lbl", 12)) { sp.edit().putInt("lbl", it).apply() }
        seek("Скругление значков, %", 0, 50, gi("rad", 28)) { sp.edit().putInt("rad", it).apply() }
        choice("Анимация появления", "ianim", listOf("Нет", "Всплытие", "Снизу вверх"), 0)
        choice("Анимация запуска", "lanim", listOf("Нет", "Из значка", "Затухание"), 1)
        row("Набор значков", "ADW, Nova, Apex и GO") {
            val ps = packs(); menu("Набор значков", listOf<CharSequence>("По умолчанию") + ps.map { it.loadLabel(packageManager) }) { i -> sp.edit().putString("pack", if (i == 0) "" else ps[i - 1].activityInfo.packageName).apply(); load() }
        }

        sec("ЯЩИК И ПОИСК")
        seek("Колонок в ящике", 2, 7, gi("dcols", 4)) { sp.edit().putInt("dcols", it).apply() }
        choice("Вид ящика", "dstyle", listOf("Сетка", "Список"), 0)
        choice("Анимация ящика", "danim", listOf("Снизу вверх", "Масштаб", "Нет"), 0)
        choice("Сортировка", "sort", listOf("А — Я", "Я — А", "Сначала новые", "Сначала частые"), 0)
        seek("Прозрачность фона ящика", 0, 255, gi("dalpha", 235)) { sp.edit().putInt("dalpha", it).apply() }
        sw("Недавние приложения и запросы", null, "recent", true)
        choice("Поисковая система", "engine", ENGINES.map { it.first }, 0)
        sw("Искать в контактах", "Потребуется разрешение", "scont", true)
        sw("Подсказки из интернета", "Набранный текст отправляется в DuckDuckGo", "sweb", true)
        row("Очистить историю", null) { clearHistory(); toast("История очищена") }

        sec("ЖЕСТЫ")
        seek("Чувствительность свайпа (меньше — легче)", 1000, 4000, gi("gsens", 1800)) { sp.edit().putInt("gsens", it).apply() }
        gest("Свайп вверх", "g_up", 9); gest("Свайп вниз", "g_down", 1)
        gest("Свайп вверх по доку", "g_dock", 9)
        gest("Два пальца вверх", "g2_up", 0); gest("Два пальца вниз", "g2_down", 2)
        gest("Три пальца вверх", "g3_up", 0); gest("Три пальца вниз", "g3_down", 0)
        gest("Щипок (сжать)", "g_pin", 10); gest("Щипок (развести)", "g_pout", 0)
        gest("Двойной тап", "g_dbl", 3); gest("Долгое нажатие на пустом месте", "g_long", 10)
        gest("Свайп вправо на первой странице", "g_p0", 0); gest("Свайп влево на последней странице", "g_pl", 0)
        gest("Нажатие на часы", "g_clock", 21); gest("Долгое нажатие на строку поиска", "g_sbl", 15)
        row("Служба специальных возможностей", "Нужна для блокировки, недавних, меню питания и скриншота") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        sec("ВНЕШНИЙ ВИД")
        seek("Размытие обоев (Android 12+)", 0, 100, gi("wblur", 0)) { sp.edit().putInt("wblur", it).apply() }
        row("Сменить обои", null) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои")) }

        sec("ПРИЛОЖЕНИЯ")
        sw("Значки уведомлений", null, "badges", true)
        row("Доступ к уведомлениям", "Нужен для значков уведомлений") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        row("Скрытые приложения", "Нажмите на приложение, чтобы вернуть") {
            val h = hidden().toList()
            if (h.isEmpty()) toast("Скрытых приложений нет") else menu("Вернуть приложение", h.map { p -> apps.find { it.pkg == p }?.label ?: p }) { i -> unhide(h[i]) }
        }
        row("Сбросить переименования", null) { sp.edit().remove("ren").apply(); load() }

        sec("СИСТЕМА И КОПИИ")
        row("Сделать Orion основным лаунчером", null) { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        row("Сохранить копию настроек в файл", "Включая расположение значков") { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, "orion-backup.json"), 11) }
        row("Восстановить из файла", null) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 12) }
        row("Копировать настройки в буфер", null) { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("orion", backupJson())); toast("Скопировано") }
        row("Восстановить из буфера", null) { try { applyBackup((getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip!!.getItemAt(0).text.toString()) } catch (ex: Exception) { toast("В буфере нет копии Orion") } }
        row("Сбросить все настройки", "Вернёт лаунчер к начальному виду") {
            menu("Сбросить все настройки?", listOf("Сбросить", "Отмена")) { i -> if (i == 0) { sp.edit().clear().apply(); hcache = null; fcache = null; lay.load(); wcache.clear(); applyAll(); load() } }
        }
        gd(ScrollView(this).apply { addView(c) }, 0.4f)
    }
}
