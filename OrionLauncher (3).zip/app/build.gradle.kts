plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.orion.launcher"
    compileSdk = 34
    defaultConfig { applicationId = "com.orion.launcher"; minSdk = 26; targetSdk = 34; versionCode = 3; versionName = "2.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.recyclerview:recyclerview:1.3.2"); implementation("androidx.core:core-ktx:1.13.1") }
